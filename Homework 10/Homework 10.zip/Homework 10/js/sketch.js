var topX = 250;
var topY = 170;
var topDirection = 1;

var bottomX = 200;
var bottomY = 250;
var bottomDirection = 3;

var sideX = 300;
var sideY = 250;
var sideDirection = 8;

var middleX = 200;
var middleY = 150;
var middleDirection = 6;

var size = 32;
var count = 0;
var sizeDirection = 3;

function setup()
{
    createCanvas(500, 600);
}

function draw()
{
    background(120,45,78);

    textSize(size);
    size+=sizeDirection;
    count++;
    if(count > 5)
    {
        sizeDirection *=-1;
        count = 0;
    }
    text('Garrett Boehm', 10, 30);
    
    fill('rgb(0,255,0)');
    circle(topX,topY,175);
    topX+=topDirection;
    if(topX >= 410 || topX <= 82)
    {
        topDirection *= -1;
    }
    
    fill(10,124,130);
    rect(200,bottomY,200,250);
    bottomY += bottomDirection;
    if(bottomY <= 0 || bottomY >= 450)
    {
        bottomDirection *= -1;
    }

    fill(10, 274, 130)
    rect(150,middleY,240,190);
    middleY += middleDirection;
    if(middleY <= 0|| middleY >= 450)
    {
        middleDirection *= -1;
    }

    fill(17, 178, 0);
    circle(sideX,sideY,175);
    sideX+=sideDirection;
    if(sideX >= 410 || sideX <= 82)
    {
        sideDirection *= -1;
    }

    line(150, 250, 85, 75);
    point(250,170)
}