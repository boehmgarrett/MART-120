var characterX = 100;
var characterY = 100;

var w = 87;
var s = 83;
var a = 65;
var d = 68;

var shapeX = 40;
var shapeY = 60;

var shape2X = [];
var shape2Y = [];
var diameter = [];

var shapeXSpeed = [];
var shapeYSpeed = [];

var mouseShapeX;
var mouseShapeY;

function setup()
{
    createCanvas(750, 750);
    for(var i = 0; i < 70; i++){
        shapeXSpeed[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
        shapeYSpeed[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
        shape2X[i] = randomNumber(750);
        shape2Y[i] = randomNumber(750);
        diameter[i] = randomNumber(30);
    }
    character(210, 360);
}

function draw()
{
    background(255);
    stroke(0);
    tree(350,350,10)
    lake(250,250,40)
    rock(240,350,10)
    tallhill(350,586,10)
    tree2(520,630,10)
    

    fill(150, 75, 0);
    
    createBorders(10);

    textSize(14);
    text('Home', width-50,height-50)

    makeCharacter();
    movement();

    fill(0, 255, 255);
    
    for (var i = 0; i < shape2X.length; i++){
        circle(shape2X[i], shape2Y[i], diameter[i]);
        shapeXSpeed[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
        shapeYSpeed[i] = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
    
        shape2X[i] += shapeXSpeed[i];
        shape2Y[i] += shapeYSpeed[i];

        if (shape2X[i] > width){
            shape2X[i] = 0;
        }
        if (shape2X[i] < 0){
            shape2X[i] = width;
        }
        if (shape2Y[i] > height){
            shape2Y[i] = 0;
        }
        if (shape2Y[i] < 0){
            shape2Y[i] = height;
        }
    }

    if(characterX > width && characterY > width-50)
    {
        fill(255,0,0);
        stroke(5);
        textSize(25);
        text("Merry Christmas!!!", width/2-50, height/2-50);
    }
    fill(0);
    circle(mouseShapeX, mouseShapeY, 45);
}

function movement() {
    if(keyIsDown(w)){
        characterY -= 10;
    }
    if(keyIsDown(s)){
        characterY += 10;
    }
    if(keyIsDown(a)){
        characterX -= 10;
        console.log("move: " + characterX);
    }
    if(keyIsDown(d)){
        characterX += 10;
    }
}

function character(x,y)
{
    characterX = x;
    characterY = y;
}

function makeCharacter()
{
    fill(255,0,0);
    circle(characterX,characterY,25);
}

function createBorders(thicker)
{
    rect(0,0,width,thicker);
    rect(0,0,thicker,height);
    rect(0, height-thicker,width, thicker);
    rect(width-thicker,0,thicker,height-50);
}

function mouseClicked()
{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}

function randomNumber(number){
    return Math.floor(Math.random() * number) + 10;
}

function tree(x,y,size) {
    fill(80,30,20);
    rect(x-size,y,size*2,size*6);
    fill(20,130,5);
    triangle(x-size*3,y,x,y-size*8,x+size*3,y)
}

function lake(x,y,size) {
    fill(0,0,255)
    circle(150, 150, 210);
}

function rock(x,y,size){
    fill(120,130,140)
    ellipse(120, 660, 80, 40)
}

function tallhill(){
    fill(24, 112, 153);
    triangle(500, 400, 650, 400, 680, 150);
}

function tree2(x,y,size){
    fill(150,75,0);
    rect(x-size,y,size*3,size*8);
    fill(38, 230, 0);
    triangle(x-size*8,y,x,y-size*16,x+size*8,y)
}