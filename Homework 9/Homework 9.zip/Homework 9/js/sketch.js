function setup()
{
    createCanvas(500, 600);
}

function draw()
{
    background(120,45,78);
    textSize(32);
    text('Garrett Boehm', 10, 30);
    fill('rgb(0,255,0)');
    circle(250,170,175)
    fill(10,124,130);
    rect(150,250,200,250);
    line(150, 250, 85, 75);
    point(250,170)
}